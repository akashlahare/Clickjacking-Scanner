const express = require("express");
const axios = require("axios");
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors()); // Allow frontend to connect
app.use(express.json()); // Parse JSON body

// ✅ Root route for testing
app.get("/", (req, res) => {
    res.send("🛡️ Clickjacking Scanner API is running!");
});

// API to scan for Clickjacking vulnerability
app.post("/scan", async (req, res) => {
    let { url } = req.body;

    if (!url) return res.json({ error: "URL is required" });

    // Ensure URL has "http://" or "https://"
    if (!/^https?:\/\//i.test(url)) {
        url = `https://${url}`;
    }

    try {
        const response = await axios.get(url, { timeout: 5000 });

        const headers = response.headers;
        let isVulnerable = true;
        let recommendation = "Quick Recommendation: Implement 'X-Frame-Options: DENY' or 'frame-ancestors' in the Content Security Policy (CSP) to prevent clickjacking.";
        let vulnerabilityName = "Clickjacking";
        let description = "Clickjacking is a web security vulnerability that allows attackers to trick users into clicking on hidden elements by embedding the target website in an iframe.";

        if (
            headers["x-frame-options"] ||
            (headers["content-security-policy"] &&
             headers["content-security-policy"].includes("frame-ancestors"))
        ) {
            isVulnerable = false;
            recommendation = "Quick Recommendation: No action required. The website is secure against clickjacking.";
        }

        res.json({
            url,
            isVulnerable,
            vulnerabilityName,
            description,
            recommendation
        });
    } catch (error) {
        res.json({ error: "Could not scan the website. It may be blocking requests." });
    }
});

// Start the server
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
